#!/usr/bin/env python3
"""PC 용량 정리 스캐너 (macOS / Windows, 파이썬 표준 라이브러리만 사용).

읽기 전용이다. 아무것도 지우거나 옮기지 않고 아래 두 파일만 만든다.
  <work>/plan.json  실행 계획 (serve.py가 '실행' 버튼을 누를 때 이것만 보고 움직인다)
  <work>/data.js    화면용 데이터 (파일 경로는 빼고, 이름은 가린다)

사용:
  python3 scan.py --work ~/pc-cleanup [--archive-dir <클라우드 폴더>] [--show-names]
"""
import argparse, collections, hashlib, json, os, re, shutil, subprocess, sys, time

WIN = os.name == "nt"
MAC = sys.platform == "darwin"
HOME = os.path.expanduser("~")
NOW = time.time()
DAY = 86400
DESKTOP_DAYS = 30
DOWNLOADS_DAYS = 14
BIG = 500 * 1024 * 1024
MIN_DUP = 100 * 1024

# 화면에 파일명을 그대로 보여도 되는 패턴. 나머지는 ●●●●●● 로 가린다.
SAFE_NAME = re.compile(r"^(Screenshot |Screen Recording |스크린샷 |화면 기록 |IMG_\d|PHOTO-\d|image|images|KakaoTalk_|[0-9a-f]{24,})", re.I)
# 개인 서류로 보이는 파일은 클라우드로 올리지 않고 그대로 둔다. 사용자가 직접 확인한다.
PERSONAL = re.compile(r"(passport|여권|visa|비자|주민|등본|가족관계|contract|계약|arbeitsvertrag|mietvertrag|invoice|rechnung|"
                      r"überweisung|transfer confirmation|bank|은행|계좌|급여|payslip|gehalt|tax|세금|steuer|이력서|resume|lebenslauf|"
                      r"zeugnis|niederlassung|aufenthalt|driver.?licen|운전면허|insurance|보험)", re.I)
JUNK = ("Screenshot", "Screen Recording", "스크린샷", "화면 기록", "image", "images", "pngtree", "img_v3")
INSTALLER = (".dmg", ".pkg") if MAC else (".exe", ".msi") if WIN else ()
SKIP_DIRS = {"node_modules", ".git", ".venv", "venv", "__pycache__", "Library", "AppData", ".Trash", "$RECYCLE.BIN", ".cache"}


def env(k, default=""):
    return os.environ.get(k) or default


def cache_candidates():
    """지워도 쓰는 순간 자동으로 다시 만들어지는 폴더들. (경로, 설명, 타일 라벨)"""
    if MAC:
        L = os.path.join(HOME, "Library")
        C, AS = os.path.join(L, "Caches"), os.path.join(L, "Application Support")
        return [
            (os.path.join(HOME, ".npm", "_cacache"), "npm 다운로드 캐시", "npm"),
            (os.path.join(HOME, ".npm-cache"), "npm 다운로드 캐시", "npm"),
            (os.path.join(C, "Google"), "크롬 캐시", "chrome"),
            (os.path.join(C, "com.microsoft.edgemac"), "엣지 캐시", "edge"),
            (os.path.join(C, "ms-playwright"), "Playwright 브라우저 (필요하면 재설치)", "pw"),
            (os.path.join(C, "ms-playwright-mcp"), "Playwright 브라우저 (필요하면 재설치)", "pw"),
            (os.path.join(C, "pip"), "파이썬 pip 캐시", "pip"),
            (os.path.join(C, "com.apple.python"), "파이썬 바이트코드 캐시", "py"),
            (os.path.join(C, "node-gyp"), "node-gyp 헤더 캐시", "gyp"),
            (os.path.join(C, "Yarn"), "Yarn 캐시", "yarn"),
            (os.path.join(C, "Homebrew"), "Homebrew 다운로드 캐시", "brew"),
            (os.path.join(C, "us.zoom.xos"), "줌 캐시", "zoom"),
            (os.path.join(C, "com.spotify.client"), "스포티파이 캐시", "spot"),
            (os.path.join(C, "JetBrains"), "JetBrains 캐시", "jb"),
            (os.path.join(HOME, ".cache", "puppeteer"), "Puppeteer 크롬 (필요하면 재설치)", "pptr"),
            (os.path.join(HOME, ".cache", "uv"), "uv 패키지 캐시", "uv"),
            (os.path.join(AS, "Claude", "Cache"), "Claude 앱 웹 캐시", "claude"),
            (os.path.join(AS, "Claude", "Code Cache"), "Claude 앱 코드 캐시", "claude"),
            (os.path.join(AS, "Cursor", "CachedData"), "Cursor 캐시", "cursor"),
            (os.path.join(AS, "Code", "CachedData"), "VS Code 캐시", "vscode"),
            (os.path.join(AS, "Slack", "Cache"), "슬랙 캐시", "slack"),
            (os.path.join(AS, "discord", "Cache"), "디스코드 캐시", "disc"),
            (os.path.join(L, "Developer", "Xcode", "DerivedData"), "Xcode 빌드 결과물", "xcode"),
        ]
    if WIN:
        LA = env("LOCALAPPDATA", os.path.join(HOME, "AppData", "Local"))
        RA = env("APPDATA", os.path.join(HOME, "AppData", "Roaming"))
        chrome = os.path.join(LA, "Google", "Chrome", "User Data", "Default")
        edge = os.path.join(LA, "Microsoft", "Edge", "User Data", "Default")
        return [
            (os.path.join(LA, "npm-cache"), "npm 다운로드 캐시", "npm"),
            (os.path.join(RA, "npm-cache"), "npm 다운로드 캐시", "npm"),
            (os.path.join(chrome, "Cache"), "크롬 캐시", "chrome"),
            (os.path.join(chrome, "Code Cache"), "크롬 코드 캐시", "chrome"),
            (os.path.join(edge, "Cache"), "엣지 캐시", "edge"),
            (os.path.join(edge, "Code Cache"), "엣지 코드 캐시", "edge"),
            (os.path.join(LA, "ms-playwright"), "Playwright 브라우저 (필요하면 재설치)", "pw"),
            (os.path.join(LA, "pip", "Cache"), "파이썬 pip 캐시", "pip"),
            (os.path.join(LA, "Yarn", "Cache"), "Yarn 캐시", "yarn"),
            (os.path.join(LA, "uv", "cache"), "uv 패키지 캐시", "uv"),
            (os.path.join(HOME, ".cache", "puppeteer"), "Puppeteer 크롬 (필요하면 재설치)", "pptr"),
            (os.path.join(RA, "Claude", "Cache"), "Claude 앱 웹 캐시", "claude"),
            (os.path.join(RA, "Claude", "Code Cache"), "Claude 앱 코드 캐시", "claude"),
            (os.path.join(RA, "Cursor", "CachedData"), "Cursor 캐시", "cursor"),
            (os.path.join(RA, "Code", "CachedData"), "VS Code 캐시", "vscode"),
            (os.path.join(RA, "Slack", "Cache"), "슬랙 캐시", "slack"),
            (os.path.join(RA, "discord", "Cache"), "디스코드 캐시", "disc"),
            (os.path.join(LA, "Temp"), "윈도우 임시 파일", "temp"),
        ]
    return []


def known_folder(name):
    """바탕화면·다운로드 실제 위치. 윈도우는 OneDrive로 옮겨져 있을 수 있어 레지스트리를 본다."""
    if WIN:
        try:
            import winreg
            key = {"Desktop": "Desktop", "Downloads": "{374DE290-123F-4565-9164-39C4925E467B}"}[name]
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") as k:
                return os.path.expandvars(winreg.QueryValueEx(k, key)[0])
        except Exception:
            pass
    return os.path.join(HOME, name)


def dataless(st):
    # iCloud에만 있고 맥에는 없는 파일. 읽으면 다운로드가 시작되므로 건드리지 않는다.
    return MAC and bool(getattr(st, "st_flags", 0) & 0x40000000)


def dir_size(path):
    total = 0
    try:
        with os.scandir(path) as it:
            for e in it:
                try:
                    if e.is_symlink():
                        continue
                    if e.is_dir():
                        total += dir_size(e.path)
                    else:
                        total += e.stat().st_size
                except OSError:
                    pass
    except OSError:
        pass
    return total


def size_of(path):
    return dir_size(path) if os.path.isdir(path) and not os.path.islink(path) else os.lstat(path).st_size


def last_used(path):
    """마지막으로 쓴 날. 맥은 Spotlight 열람일, 윈도우는 만든 날(=다운로드한 날)과 수정일 중 늦은 쪽."""
    st = os.stat(path)
    t = st.st_mtime
    if WIN:
        t = max(t, st.st_ctime)
    if MAC:
        try:
            raw = subprocess.run(["mdls", "-raw", "-name", "kMDItemLastUsedDate", path],
                                 capture_output=True, text=True, timeout=10).stdout.strip()
            if raw and raw != "(null)":
                t = max(t, time.mktime(time.strptime(raw[:19], "%Y-%m-%d %H:%M:%S")))
        except Exception:
            pass
    return t


def kind_of(path):
    if os.path.isdir(path):
        return "folder"
    ext = os.path.splitext(path)[1].lower()
    if ext in (".png", ".jpg", ".jpeg", ".webp", ".heic", ".gif"):
        return "image"
    if ext in (".mov", ".mp4", ".m4v", ".avi", ".mkv"):
        return "video"
    if ext == ".pdf":
        return "pdf"
    if ext in (".dmg", ".pkg", ".zip", ".exe", ".msi"):
        return "archive"
    return "doc"


def md5(path, partial=False):
    h = hashlib.md5()
    with open(path, "rb") as f:
        if partial:
            h.update(f.read(1 << 16))
            f.seek(max(0, os.path.getsize(path) - (1 << 16)))
            h.update(f.read(1 << 16))
        else:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
    return h.hexdigest()


def find_duplicates(loose_dirs, other_dirs, deadline):
    """바탕화면·다운로드 맨 위 파일 중, 같은 내용의 파일이 다른 곳에 있는 사본. {사본: 원본}"""
    loose = []
    for d in loose_dirs:
        try:
            for e in os.scandir(d):
                if e.is_file(follow_symlinks=False) and not e.name.startswith("."):
                    st = e.stat()
                    if st.st_size >= MIN_DUP and not dataless(st):
                        loose.append((st.st_size, e.path))
        except OSError:
            pass
    sizes = {s for s, _ in loose}
    by_size = collections.defaultdict(list)
    for s, p in loose:
        by_size[s].append(p)
    for root in other_dirs:
        for dp, dns, fns in os.walk(root):
            if time.time() > deadline:
                break
            dns[:] = [d for d in dns if d not in SKIP_DIRS and not d.startswith(".")]
            for fn in fns:
                p = os.path.join(dp, fn)
                try:
                    st = os.stat(p, follow_symlinks=False)
                except OSError:
                    continue
                if st.st_size in sizes and not dataless(st):
                    by_size[st.st_size].append(p)
    loose_set = {p for _, p in loose}
    result = {}
    for s, paths in by_size.items():
        if len(paths) < 2 or not any(p in loose_set for p in paths):
            continue
        groups = collections.defaultdict(list)
        for p in paths:
            try:
                groups[md5(p, partial=True)].append(p)
            except OSError:
                pass
        for g in groups.values():
            if len(g) < 2:
                continue
            full = collections.defaultdict(list)
            for p in g:
                try:
                    full[md5(p)].append(p)
                except OSError:
                    pass
            for same in full.values():
                if len(same) < 2:
                    continue
                kept = [p for p in same if p not in loose_set]
                copies = [p for p in same if p in loose_set]
                if not kept:  # 바탕화면·다운로드끼리만 겹치면 가장 오래된 하나를 원본으로 남긴다
                    copies.sort(key=lambda p: os.stat(p).st_mtime)
                    kept, copies = copies[:1], copies[1:]
                for p in copies:
                    result[p] = kept[0]
    return result


def detect_archive(arg):
    """보관 폴더와 화면에 쓸 이름. 맥의 구글 드라이브는 업로드 완료를 확인할 수 있다."""
    if not arg:
        return None
    path = os.path.abspath(os.path.expanduser(arg))
    low = path.lower()
    gdrive = "googledrive-" in low or "google drive" in low or "내 드라이브" in path or "my drive" in low
    if gdrive:
        label = "구글 드라이브로"
    elif "onedrive" in low:
        label = "OneDrive로"
    elif "clouddocs" in low or "icloud" in low:
        label = "iCloud로"
    else:
        label = "보관 폴더로"
    return dict(dir=path, label=label, gdrive=gdrive, verify=MAC and "googledrive-" in low)


def make_thumb(it, work):
    """사진·영상 미리보기. 맥은 sips, 영상은 ffmpeg가 있을 때만. 없으면 serve.py가 원본 사진을 직접 보여준다."""
    rel = "thumbs/" + hashlib.md5(it["path"].encode()).hexdigest()[:12] + ".jpg"
    dst = os.path.join(work, rel)
    if not os.path.exists(dst):
        try:
            if it["kind"] == "video" and shutil.which("ffmpeg"):
                subprocess.run(["ffmpeg", "-v", "error", "-ss", "1", "-i", it["path"], "-frames:v", "1",
                                "-vf", "scale=96:96:force_original_aspect_ratio=increase,crop=96:96",
                                "-q:v", "5", dst, "-y"], timeout=30)
            elif it["kind"] == "image" and MAC:
                subprocess.run(["sips", "-s", "format", "jpeg", "-Z", "160", it["path"], "--out", dst],
                               capture_output=True, timeout=30)
        except Exception:
            pass
    if os.path.exists(dst):
        return rel
    if it["kind"] == "image" and it["size"] <= 15e6:
        return "file/%d" % it["id"]
    return None


def shown_name(name, show):
    if show or SAFE_NAME.match(name):
        return name
    ext = os.path.splitext(name)[1]
    return "●●●●●●" + ext if ext else "●●●●●● 폴더"


def write_screen(work, show_names=False):
    """plan.json → data.js. 디스크를 다시 보지 않는다."""
    plan = json.load(open(os.path.join(work, "plan.json"), encoding="utf-8"))
    tiles = []
    for it in plan["items"]:
        if it["action"] == "clear":
            # 캐시 폴더는 파일이 수만 개라 60MB당 타일 하나로 쪼갠다
            chunks = max(1, round(it["size"] / 60e6))
            for _ in range(chunks):
                tiles.append(dict(i=it["id"], b=it["bucket"], k="cache", l=it.get("label", "cache"),
                                  n=it["reason"], s=it["size"] / chunks))
        else:
            tiles.append(dict(i=it["id"], b=it["bucket"], k=it["kind"], t=it.get("thumb"),
                              n=shown_name(it["name"], show_names), s=it["size"],
                              l=os.path.splitext(it["name"])[1][1:4].upper() or "DIR"))
    arch = plan.get("archive") or {}
    screen = dict(os=plan["os"], free=plan["disk"]["free"], total=plan["disk"]["total"], reclaim=plan["reclaim"],
                  measuredAfter=plan.get("measuredAfter"), archiveLabel=arch.get("label", "보관 폴더로"),
                  archiveVerify=bool(arch.get("verify")), buckets=plan["summary"], tiles=tiles)
    with open(os.path.join(work, "data.js"), "w", encoding="utf-8") as fp:
        fp.write("window.CLEANUP = " + json.dumps(screen, ensure_ascii=False) + ";\n")
    return len(tiles)


def summarize(items):
    summary = collections.defaultdict(lambda: {"count": 0, "size": 0})
    for it in items:
        summary[it["bucket"]]["count"] += 1
        summary[it["bucket"]]["size"] += it["size"]
    return dict(summary), sum(v["size"] for k, v in summary.items() if k != "keep")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", default=os.path.join(HOME, "pc-cleanup"))
    ap.add_argument("--archive-dir", default="")
    ap.add_argument("--show-names", action="store_true")
    ap.add_argument("--dup-seconds", type=int, default=240, help="중복 찾기에 쓸 최대 시간")
    a = ap.parse_args()
    work = os.path.abspath(os.path.expanduser(a.work))
    os.makedirs(os.path.join(work, "thumbs"), exist_ok=True)
    archive = detect_archive(a.archive_dir)

    items = []

    def add(path, size, bucket, action, reason, kind=None, **extra):
        items.append(dict(id=len(items), path=path, size=size, bucket=bucket, action=action, reason=reason,
                          kind=kind or kind_of(path), name=os.path.basename(path.rstrip("/\\")), **extra))

    print("1/4 캐시 폴더 크기 재는 중", flush=True)
    seen = set()
    for path, why, label in cache_candidates():
        if os.path.isdir(path) and path not in seen:
            seen.add(path)
            s = dir_size(path)
            if s > 20e6:
                add(path, s, "cache", "clear", why, kind="cache", label=label)

    desk, dl = known_folder("Desktop"), known_folder("Downloads")
    other = [os.path.join(HOME, d) for d in ("Documents", "Pictures", "Movies", "Videos", "Music")]
    other = [d for d in other if os.path.isdir(d) and not d.startswith((desk, dl))]
    if archive:
        other = [d for d in other if not archive["dir"].startswith(d)]
    print("2/4 중복 사본 찾는 중", flush=True)
    dups = find_duplicates([desk, dl], other, time.time() + a.dup_seconds)
    for p, orig in dups.items():
        add(p, os.path.getsize(p), "dup", "trash", "원본 있음: " + orig.replace(HOME, "~"), orig=orig)

    print("3/4 바탕화면·다운로드 분류 중", flush=True)

    def archive_or_keep(p, size, reason):
        if PERSONAL.search(os.path.basename(p)):
            add(p, size, "keep", "keep", "개인 서류로 보여서 그대로 둠 (직접 확인)")
        elif archive:
            add(p, size, "archive", "archive", reason)
        else:
            add(p, size, "keep", "keep", reason + ", 보관 폴더를 정하지 않아 그대로 둠")

    for folder, days in ((desk, DESKTOP_DAYS), (dl, DOWNLOADS_DAYS)):
        try:
            names = sorted(os.listdir(folder))
        except OSError:
            continue
        for f in names:
            p = os.path.join(folder, f)
            if f.startswith(".") or f.lower() == "desktop.ini" or p in dups:
                continue
            try:
                st = os.stat(p)
                if dataless(st):
                    continue
                age = (NOW - last_used(p)) / DAY
                size = size_of(p)
            except OSError:
                continue
            if folder == dl and f.lower().endswith(INSTALLER) and age > 3:
                add(p, size, "cache", "delete", "설치가 끝난 설치 파일", kind="archive", label=f.rsplit(".", 1)[-1][:4])
            elif folder == desk and size > BIG and age > 14:
                archive_or_keep(p, size, f"대용량, {int(age)}일 미사용")
            elif folder == desk and age > days and f.startswith(JUNK):
                add(p, size, "desktop", "trash", f"{int(age)}일 동안 안 연 캡처")
            elif age > days:
                archive_or_keep(p, size, f"{int(age)}일 미사용" if folder == desk else f"다운로드 후 {int(age)}일 경과")
            else:
                add(p, size, "keep", "keep", f"최근 {int(age)}일 내 사용")

    print("4/4 미리보기 만드는 중", flush=True)
    for it in items:
        if it["kind"] in ("image", "video") and os.path.isfile(it["path"]):
            t = make_thumb(it, work)
            if t:
                it["thumb"] = t

    st = shutil.disk_usage(HOME)
    summary, reclaim = summarize(items)
    warnings = []
    if WIN and ("onedrive" in desk.lower() or "onedrive" in dl.lower()):
        warnings.append("바탕화면이나 다운로드가 OneDrive와 동기화돼 있습니다. 여기서 지운 파일은 OneDrive에서도 지워집니다.")
    plan = dict(generated=time.strftime("%Y-%m-%d %H:%M"), os="mac" if MAC else "windows" if WIN else "other",
                home=HOME, disk=dict(total=st.total, free=st.free, used=st.total - st.free),
                archive=archive, reclaim=reclaim, summary=summary, warnings=warnings, items=items)
    with open(os.path.join(work, "plan.json"), "w", encoding="utf-8") as fp:
        json.dump(plan, fp, ensure_ascii=False, indent=1)
    write_screen(work, a.show_names)

    gb = lambda b: f"{b / 1e9:.1f}GB"
    print(f"\n남은 공간 {gb(st.free)} / 전체 {gb(st.total)} | 비울 수 있는 용량 {gb(reclaim)}")
    for k in ("cache", "archive", "dup", "desktop", "keep"):
        if k in summary:
            print(f"  {k:8} {summary[k]['count']:4}개  {gb(summary[k]['size'])}")
    for w in warnings:
        print("주의:", w)
    print("계획:", os.path.join(work, "plan.json"))


if __name__ == "__main__":
    main()
