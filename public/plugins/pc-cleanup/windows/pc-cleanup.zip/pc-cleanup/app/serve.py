#!/usr/bin/env python3
"""PC 용량 정리 화면 서버. 화면의 '실행' 버튼을 눌렀을 때만 plan.json대로 정리한다.

  python3 serve.py --work ~/pc-cleanup [--port 8769] [--no-open] [--dry-run]

- 127.0.0.1에서만 열린다. 다른 웹사이트가 실행을 누르지 못하도록 Host와 전용 헤더를 확인한다.
- plan.json에 적힌 항목만, 스캔 때와 같은 상태인지 다시 확인한 뒤에 처리한다.
    캐시(clear)         폴더 안 내용을 영구 삭제. 앱을 쓰면 다시 만들어진다.
    설치 파일(delete)   영구 삭제
    사본·캡처(trash)    휴지통으로. 사본은 원본과 내용이 같은지 해시로 다시 확인한다.
    보관(archive)       보관 폴더로 복사하고 크기·해시를 확인한다.
                        맥 구글 드라이브: 업로드 완료 표시가 붙은 뒤에 원본 영구 삭제
                        그 밖의 폴더: 원본은 휴지통으로 (동기화를 확인한 뒤 직접 비우기)
--dry-run 이면 아무것도 건드리지 않고 화면만 실제처럼 움직인다.
"""
import argparse, csv, json, os, shutil, subprocess, sys, threading, time, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, unquote

APP = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP)
from scan import write_screen, md5, known_folder, WIN, MAC, HOME  # noqa: E402

TYPES = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
         ".json": "application/json; charset=utf-8", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
         ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp", ".heic": "image/heic"}
GDRIVE_ATTR = "com.google.drivefs.item-id#S"
UPLOAD_TIMEOUT = 60 * 60


def free_bytes():
    return shutil.disk_usage(HOME).free


def safe_target(p, action):
    """홈 폴더 안의 항목만. 홈 자체나 바탕화면·다운로드 폴더 통째로는 절대 안 된다."""
    p = os.path.abspath(p)
    rel = os.path.relpath(p, HOME)
    if rel.startswith("..") or os.path.isabs(rel) or rel == ".":
        return False
    depth = len([x for x in rel.replace("\\", "/").split("/") if x])
    return depth >= 2 or (action == "clear" and os.path.basename(p).startswith("."))


def move_to_trash(p):
    if WIN:
        kind = "DeleteDirectory" if os.path.isdir(p) else "DeleteFile"
        script = ("Add-Type -AssemblyName Microsoft.VisualBasic; "
                  f"[Microsoft.VisualBasic.FileIO.FileSystem]::{kind}($env:PCC_PATH,'OnlyErrorDialogs','SendToRecycleBin')")
        r = subprocess.run(["powershell", "-NoProfile", "-Command", script], capture_output=True, text=True,
                           env={**os.environ, "PCC_PATH": p}, timeout=300)
        if r.returncode != 0 or os.path.exists(p):
            raise OSError("휴지통으로 못 옮김: " + r.stderr.strip()[:200])
        return
    trash = os.path.join(HOME, ".Trash") if MAC else os.path.join(HOME, ".local", "share", "Trash", "files")
    os.makedirs(trash, exist_ok=True)
    dest = os.path.join(trash, os.path.basename(p))
    if os.path.exists(dest):
        stem, ext = os.path.splitext(os.path.basename(p))
        dest = os.path.join(trash, f"{stem} {time.strftime('%H.%M.%S')}{ext}")
    shutil.move(p, dest)


def remove(p):
    if os.path.isdir(p) and not os.path.islink(p):
        shutil.rmtree(p)
    else:
        os.remove(p)


def clear_dir(p):
    """캐시 폴더는 폴더는 남기고 안의 내용만 지운다. 사용 중이라 못 지운 파일은 건너뛴다."""
    with os.scandir(p) as it:
        for e in list(it):
            try:
                if e.is_dir(follow_symlinks=False):
                    shutil.rmtree(e.path, ignore_errors=True)
                else:
                    os.remove(e.path)
            except OSError:
                pass


def tree_files(p):
    if os.path.isfile(p):
        return [p]
    out = []
    for dp, _, fns in os.walk(p):
        out += [os.path.join(dp, f) for f in fns if not f.startswith(".")]
    return out


def tree_sig(p):
    files = tree_files(p)
    return len(files), sum(os.path.getsize(f) for f in files)


def uploaded(p):
    """구글 드라이브 데스크톱 앱은 업로드가 끝난 파일에 드라이브 파일 ID를 붙인다."""
    for f in tree_files(p):
        r = subprocess.run(["xattr", "-p", GDRIVE_ATTR, f], capture_output=True, text=True)
        v = r.stdout.strip()
        if r.returncode != 0 or not v or v.startswith("local"):
            return False
    return True


def unique(dest):
    if not os.path.exists(dest):
        return dest
    stem, ext = os.path.splitext(dest)
    n = 2
    while os.path.exists(f"{stem} ({n}){ext}"):
        n += 1
    return f"{stem} ({n}){ext}"


class Runner:
    def __init__(self, work, dry):
        self.work, self.dry = work, dry
        self.plan = json.load(open(os.path.join(work, "plan.json"), encoding="utf-8"))
        self.items = {it["id"]: it for it in self.plan["items"]}
        self.lock = threading.Lock()
        self.state, self.status, self.log = "idle", {}, []
        self.start_free = self.end_free = None
        self.freed_dry = self.trash = 0
        self.errors = []
        self.desk, self.dl = known_folder("Desktop"), known_folder("Downloads")

    def snapshot(self):
        with self.lock:
            free = self.start_free + self.freed_dry if self.dry and self.start_free else free_bytes()
            return dict(state=self.state, items=dict(self.status), log=self.log[-8:], seq=len(self.log),
                        free=free, startFree=self.start_free, trash=self.trash, dry=self.dry)

    def mark(self, it, status, text=None):
        with self.lock:
            self.status[it["id"]] = status
            if text:
                self.log.append(dict(id=it["id"], text=text, status=status))

    def start(self):
        with self.lock:
            if self.state != "idle":
                return False
            self.state, self.start_free = "running", free_bytes()
        threading.Thread(target=self.run, daemon=True).start()
        return True

    def run(self):
        todo = [it for it in self.plan["items"] if it["action"] != "keep"]
        rank = {"clear": 0, "delete": 1, "trash": 2, "archive": 3}
        todo.sort(key=lambda it: (rank[it["action"]], -it["size"]))
        pending = []
        for it in todo:
            self.mark(it, "busy")
            try:
                if not os.path.lexists(it["path"]):
                    self.mark(it, "skipped", "이미 없음")
                    continue
                if not safe_target(it["path"], it["action"]):
                    self.mark(it, "error", "범위 밖, 건너뜀")
                    continue
                getattr(self, "do_" + it["action"])(it, pending)
            except Exception as e:  # 한 항목이 실패해도 나머지는 계속
                self.mark(it, "error", "실패: " + type(e).__name__)
                self.errors.append(dict(path=it["path"], error=str(e)[:300]))
        self.wait_uploads(pending)
        self.finish()

    def gone(self, it, text, trashed=False):
        with self.lock:
            if self.dry and not trashed:
                self.freed_dry += it["size"]
            if trashed:
                self.trash += it["size"]
        self.mark(it, "done", text)

    def do_clear(self, it, _):
        if self.dry:
            time.sleep(min(1.5, .2 + it["size"] / 8e9))
        else:
            clear_dir(it["path"])
        self.gone(it, "삭제 완료")

    def do_delete(self, it, _):
        if not self.dry:
            if os.path.getsize(it["path"]) != it["size"]:
                return self.mark(it, "skipped", "바뀌어서 건너뜀")
            os.remove(it["path"])
        self.gone(it, "삭제 완료")

    def do_trash(self, it, _):
        if self.dry:
            time.sleep(.03)
            return self.gone(it, "휴지통으로", trashed=True)
        if os.path.isfile(it["path"]) and os.path.getsize(it["path"]) != it["size"]:
            return self.mark(it, "skipped", "바뀌어서 건너뜀")
        if it.get("orig"):
            o = it["orig"]
            if not os.path.isfile(o) or md5(o) != md5(it["path"]):
                return self.mark(it, "skipped", "원본 확인 안 됨")
        move_to_trash(it["path"])
        self.gone(it, "휴지통으로", trashed=True)

    def do_archive(self, it, pending):
        arch = self.plan["archive"]
        if self.dry:
            time.sleep(.05)
            if arch.get("verify"):
                self.mark(it, "uploading", "업로드 중")
                pending.append((it, None))
            else:
                self.gone(it, "보관 완료", trashed=True)
            return
        sub = "Desktop" if it["path"].startswith(self.desk) else "Downloads"
        dest = unique(os.path.join(arch["dir"], sub, it["name"]))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        if os.path.isdir(it["path"]):
            shutil.copytree(it["path"], dest, symlinks=True)
            ok = tree_sig(it["path"]) == tree_sig(dest)
        else:
            shutil.copy2(it["path"], dest)
            ok = os.path.getsize(dest) == os.path.getsize(it["path"]) and md5(dest) == md5(it["path"])
        if not ok:
            return self.mark(it, "error", "복사 확인 실패")
        self.index(it, dest)
        if arch.get("verify"):
            self.mark(it, "uploading", "업로드 중")
            pending.append((it, dest))
        else:
            move_to_trash(it["path"])
            self.gone(it, "보관 완료", trashed=True)

    def index(self, it, dest):
        path = os.path.join(self.plan["archive"]["dir"], "00_INDEX.csv")
        new = not os.path.exists(path)
        with open(path, "a", newline="", encoding="utf-8-sig") as fp:
            w = csv.writer(fp)
            if new:
                w.writerow(["보관 위치", "원래 위치", "MB", "정리한 날"])
            w.writerow([os.path.relpath(dest, self.plan["archive"]["dir"]), it["path"].replace(HOME, "~"),
                        round(it["size"] / 1e6, 2), time.strftime("%Y-%m-%d")])

    def wait_uploads(self, pending):
        deadline = time.time() + UPLOAD_TIMEOUT
        while pending and time.time() < deadline:
            for pair in list(pending):
                it, dest = pair
                if self.dry or uploaded(dest):
                    if not self.dry:
                        remove(it["path"])
                    self.gone(it, "업로드 완료")
                    pending.remove(pair)
                    if self.dry:
                        time.sleep(.04)
            time.sleep(.2 if self.dry else 3)
        for it, _ in pending:
            self.mark(it, "error", "업로드 대기 초과")

    def finish(self):
        snap = self.snapshot()
        with self.lock:
            self.state, self.end_free = "done", snap["free"]
        report = dict(finished=time.strftime("%Y-%m-%d %H:%M"), dry=self.dry, startFree=self.start_free,
                      endFree=self.end_free, trash=self.trash,
                      items=[dict(path=self.items[i]["path"], action=self.items[i]["action"], status=s)
                             for i, s in sorted(self.status.items())],
                      errors=self.errors, log=self.log)
        name = "report-dry.json" if self.dry else "report.json"
        with open(os.path.join(self.work, name), "w", encoding="utf-8") as fp:
            json.dump(report, fp, ensure_ascii=False, indent=1)


def make_handler(runner, port):
    hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    origins = {f"http://{h}" for h in hosts}

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def send(self, code, body, ctype="application/json; charset=utf-8"):
            if isinstance(body, (dict, list)):
                body = json.dumps(body, ensure_ascii=False).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def file(self, path):
            try:
                with open(path, "rb") as f:
                    self.send(200, f.read(), TYPES.get(os.path.splitext(path)[1].lower(), "application/octet-stream"))
            except OSError:
                self.send(404, {"error": "없음"})

        def do_GET(self):
            if self.headers.get("Host") not in hosts:
                return self.send(403, {"error": "host"})
            path = unquote(urlparse(self.path).path)
            if path in ("/", "/index.html"):
                return self.file(os.path.join(APP, "index.html"))
            if path == "/data.js":
                return self.file(os.path.join(runner.work, "data.js"))
            if path == "/api/status":
                return self.send(200, runner.snapshot())
            if path.startswith("/thumbs/"):
                p = os.path.abspath(os.path.join(runner.work, path.lstrip("/")))
                if p.startswith(os.path.join(runner.work, "thumbs") + os.sep):
                    return self.file(p)
            if path.startswith("/file/"):
                it = runner.items.get(int(path[6:]) if path[6:].isdigit() else -1)
                if it and it["kind"] == "image" and it["size"] <= 15e6:
                    return self.file(it["path"])
            self.send(404, {"error": "없음"})

        def do_POST(self):
            # 다른 사이트에서 보낸 요청은 Host·Origin·전용 헤더 중 하나라도 어긋나므로 막힌다
            if (self.headers.get("Host") not in hosts or self.headers.get("X-PC-Cleanup") != "1"
                    or self.headers.get("Origin", next(iter(origins))) not in origins):
                return self.send(403, {"error": "forbidden"})
            if urlparse(self.path).path == "/api/execute":
                return self.send(202 if runner.start() else 409, runner.snapshot())
            self.send(404, {"error": "없음"})

    return H


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", default=os.path.join(HOME, "pc-cleanup"))
    ap.add_argument("--port", type=int, default=8769)
    ap.add_argument("--no-open", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    work = os.path.abspath(os.path.expanduser(a.work))
    write_screen(work)
    runner = Runner(work, a.dry_run)
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), make_handler(runner, a.port))
    url = f"http://localhost:{a.port}/"
    print(("[연습 모드: 아무것도 지우지 않음] " if a.dry_run else "") + "화면 주소: " + url, flush=True)
    if not a.no_open:
        webbrowser.open(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
